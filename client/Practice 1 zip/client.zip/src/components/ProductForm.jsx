import React, {useState} from 'react'


const ProductForm = () => {


    const [title, setTitle] = useState("")
    const [price, setPrice] = useState()
    const [description, setDescription] = useState()

    const submitProductHandler = (e) => {
        e.preventDefault();
        console.log(title, price, description)
        
      
    }


  return (
    <div>
        <form onSubmit={submitProductHandler} className='form-group'>
            <p>
                <label>Title</label>
                <input onChange={e => setTitle(e.target.value)} type="text" name="" id=""/>
            </p>
            <p>
                <label>Price</label>
                <input onChange={e =>setPrice(e.target.value)} type="number" name="" id="" />
            </p>
            <p>
                <label>Description</label>
                <input onChange={e =>setDescription(e.target.value)} type="text" name="" id="" />
            </p>
            <button className="btn btn-primary">Submit</button>
          
        </form>
    </div>
  )
}

export default ProductForm