
import './App.css';
import ProductForm from './components/ProductForm';
import React from "react";
import {
  BrowserRouter,
  Switch,
  Route,
  Link
} from "react-router-dom";

/* collect info from form
 -- state variables for form info
when form submits, send post request using axios
info to create something new*/
function App() {
  return (
    <BrowserRouter>

      <div className="App" >
        <h1>
          Product Manager
        </h1>

        <Switch>
          <Route exact path="/">
            <ProductForm />
          </Route>
        </Switch>
      </div >


    </BrowserRouter>

  );
}

export default App;
