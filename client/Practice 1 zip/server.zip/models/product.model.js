// 3
const mongoose = require("mongoose");

// create schema
const ProductSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Title is required."],
    minlength: [2, "Title must be at least 2 characters."],
  },
  price: {
    type: Number,
    required: [true, "Punchline is required"],
    min: [0, "Price must be more than zero"],
  },
  description:{
      type: String,
      required: [true, "Description is required"],
      minlength: [2, "Description must be at least 2 characters."]
  },
}, {timestamps: true});

const Product = mongoose.model("Product", ProductSchema);

module.exports = Product;
