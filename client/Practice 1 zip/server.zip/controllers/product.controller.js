const Product = require("../models/product.model");

module.exports.index = (req, res) => {
  res.json("Hello");
};

// ------ 8 WRITE THE ROUTE ONE BY ONE
// 7 do the CRUD

// FIND ALL / GET ALL products ----GET
module.exports.allProducts = (req, res) => {
  // console.log("server/controller")
  Product.find()
    .then((allProducts) => res.json({ products: allProducts }))
    .catch((err) => res.json({ message: "Something went wrong" }));
};

// CREATE Product---POST #8

module.exports.createProduct = (req, res) => {
  Product.create(req.body)
    .then((newProduct) =>
      res.json({
        result: newProduct,
      })
    )
    .catch((err) =>
      res.json({
        message: "Something went wrong",
        error: err,
      })
    );
};

//FIND ONE -- GET
module.exports.oneProduct = (req, res) => {
  Product.findOne({ _id: req.params.id })
    .then((product) => res.json({ product: product }))
    .catch((err) => res.json({ message: "Something went wrong", error: err }));
};

// UPDATE A REMINDER ----/PUT-----
// UPDATE (FINDONE + CREATE)
module.exports.updateProduct = (req, res) => {
    console.log("updating product")
  Product.findOneAndUpdate({ _id: req.params.id }, req.body, {
    new: true,
    runValidators: true,
  })
    .then((product) => res.json({ product: product }))
    .catch((err) => res.json({ message: "Something went wrong", error: err }));
};

// DELETE A REMINDER
module.exports.deleteProduct = (req, res) => {
  console.log("deleting a product");
  Product.deleteOne({ _id: req.params.id })
    .then((result) => res.json({ result: result }))
    .catch((err) => res.json({ message: "Something is wrong", error: err }));
};

