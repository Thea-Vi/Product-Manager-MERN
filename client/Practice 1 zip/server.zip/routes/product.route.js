const ProductController = require("../controllers/product.controller")

module.exports = app => {
    console.log("server/routes")
    app.get("/", ProductController.index) //INDEX
    app.get("/api/products", ProductController.allProducts) //GETALL
    app.post("/api/products", ProductController.createProduct) //9 //POST CREATE
    // dynamic bottom
    app.get("/api/products/:id", ProductController.oneProduct) //GET ONE
    app.put("/api/products/:id", ProductController.updateProduct) //UPDATE
    app.delete("/api/products/:id", ProductController.deleteProduct) //DELETE
}


